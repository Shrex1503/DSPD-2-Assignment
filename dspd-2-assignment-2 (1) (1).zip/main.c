
//Railway database management using B trees
#define NAME_SIZE 40
#define MAX 4
#define MIN_SIZE 2
#define MAX_TREE_SIZE 20
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

//typedef enum {Sleeper,AC3,AC2,AC1} class;
//typedef enum {Cancelled,Promoted} status;
typedef enum {false,true} bool;
typedef struct Passenger{
	char name[NAME_SIZE];
    int passengerID; 
    char boarding_train[20];
    char boarding_station[20];
    int train_class;
    char destination_station[20];
    int train_no;
    int seat_no;
    int date;//ddmmyy
    int key;
}Passenger;

typedef struct TreeNode
{
    Passenger data[MAX+1];
    struct TreeNode *ptr[MAX+1];
    int size;
}TreeNode;
TreeNode *root = NULL;
Passenger update_record(char name[],int id,char b_t[],char b_s[],int train_class,char d_s[],int t_id)
{
    Passenger passenger_record;
    strcpy(passenger_record.name,name);
    passenger_record.passengerID=id;
    strcpy(passenger_record.boarding_train,b_t);
    strcpy(passenger_record.boarding_station,b_s);
    passenger_record.train_class=train_class;
    strcpy(passenger_record.destination_station,d_s);
    passenger_record.train_no=t_id;
    //passenger_record.seat_no=s_n;
    //passenger_record.date=dd;
    return passenger_record;
}
TreeNode* newNode(Passenger passenger_record,TreeNode *child)
{
    TreeNode* node=(TreeNode*)malloc(sizeof(TreeNode));
    node->data[1]=passenger_record;
    node->size=1;
    node->ptr[0] =root;
    node->ptr[1]=child;
    return node;
}
void insertNode(Passenger passenger_record,int pos,TreeNode* node,TreeNode* child)
{
    int i;
    for(i=node->size;i>pos;i--)
    {
        node->data[i+1]=node->data[i];
        node->ptr[i+1]=node->ptr[i];
    }
    node->data[i+1]=passenger_record;
    node->ptr[i+1]=child;
    node->size++;
}
void splitNode(Passenger passenger_record,Passenger *p_record,int pos,TreeNode *node,TreeNode *child,TreeNode **new_node)
{
    int median,i;
    if(pos>MIN_SIZE)
        median=MIN_SIZE+1;
    else
        median=MIN_SIZE;
    new_node=(TreeNode)malloc(sizeof(TreeNode));
    i=median+1;
    while(i<=MAX)
    {
        (*new_node)->data[i-median]=node->data[i];
        (*new_node)->ptr[i-median]=node->ptr[i];
        i++;
    }
    node->size=median;
    (*new_node)->size=MAX-median;
    if(pos<=-MIN_SIZE)
        insertNode(passenger_record,pos,node,child);
    else
        insertNode(passenger_record,pos-median,*new_node,child);
    *p_record=node->data[node->size];
    (*new_node)->ptr[0]=node->ptr[node->size];
    node->size--;
}

bool setvaluebydate(Passenger passenger_record,Passenger *p_record,TreeNode *node, TreeNode **child){
    int pos;
    if(!node)
    {
        *p_record=passenger_record;
        *child=NULL;
        return true;
    }
    if(passenger_record.date<=node->data[1].date)
        pos=0;
    else
    {
        for(pos=node->size;passenger_record.date<=node->data[pos].date&&pos>1;pos--);
    }
    if(setvaluebydate(passenger_record,p_record,node->ptr[pos],child))
    {
        if(node->size<MAX)
            insertNode(*p_record,pos,node,*child);
        else
        {
            splitNode(*p_record,&passenger_record,pos,node,*child,child);
            return true;
        }
    }
    return false;
}


bool setValuebyKey(Passenger passenger_record,Passenger p_record,TreeNode*node,TreeNode*child)
{
    int pos;
    if(!node)
    {
        *p_record=passenger_record;
        *child=NULL;
        return true;
    }
    if(passenger_record.key<node->data[1].key)
        pos=0;
    else
    {
        for(pos=node->size;passenger_record.key<node->data[pos].key&&pos>1;pos--);
        if(passenger_record.key==node->data[pos].key)
        {
            node->data[pos]=passenger_record;
            return false;
        }
    }
    if(setValuebyKey(passenger_record,p_record,node->ptr[pos],child))
    {
        if(node->size<MAX)
            insertNode(*p_record,pos,node,*child);
        else
        {
            splitNode(*p_record,&passenger_record,pos,node,*child,child);
            return true;
        }
    }
    return false;
}

bool insert(TreeNode *node,char name[],int id,char b_t[],char b_s[],int train_class,char d_s[],int t_id)
{
    Passenger i,passenger_record=update_record(name,id,b_t,b_s,train_class,d_s,t_id);
    bool flag;
    TreeNode *child;
    flag=setValuebyKey(passenger_record,&i,node,&child);
    if(flag)
    {
        node=newNode(i,child);
    }
    return flag;
}
void insertbydate(TreeNode *node,Passenger passenger_record){
    Passenger i;
    bool flag;
    TreeNode *child;
    flag=setvaluebydate(passenger_record,&i,node,&child);
    if(flag){
        node=newNode(i,child);
    }
    
}

void getListDestination(struct node *head)
{
    int train_no;
    char destination_station[20];
    struct node *ptr=head;
    printf("Enter the train ID and destination station you want to get the list for:\n");
    scanf("%d %s",&train_no,destination_station);
    
    while(ptr!=NULL && ptr->record.train_no != train_no)
    {
        ptr=ptr->next;
    }
    if(ptr==NULL)
    {
        printf("No such list found!!\n");
    }
    else
    {
        printf("\nThe list is : \n");
        while(ptr->record.train_no == train_no)
        {
            if(strcmp(ptr->record.destination_station,destination_station)==0)
            {
                printf("%s %s\t%d\n",ptr->record.first_name,ptr->record.last_name,ptr->record.passengerID);
            }
            ptr=ptr->next;
        }   
    }
}


void print_details(TreeNode *node)
{
    int i;
    char *class_arr[]={"Sleeper","3AC","2AC","1AC"};
    //char *status_arr[]={"Cancelled","Promoted"};
    if(node)
    {
        for(i=0;i<node->size;i++)
        {
            print_details(node->ptr[i]);
            printf("Name: %s\nID: %d\nClass: %s\nBoarding train: %s\nBoarding station: %s\ndestination station:%s\n",node->data[i+1].name,node->data[i+1].passengerID,class_arr[node->data[i+1].train_class],node->data[i+1].boarding_train,node->data[i+1].boarding_station,node->data[i+1].destination_station);
	        printf("Train id:%d",node->data[i+1].train_no);
        }
        print_details(node->ptr[i]);
    }
}
void printTrain(Passenger p)
{
    char *class_arr[]={"Sleeper","3AC","2AC","1AC"};
    printf("Name: %s\nID: %d\nClass: %s\nBoarding train: %s\nBoarding station: %s\ndestination station:%s\n",p.name,p.passengerID,class_arr[p.train_class],p.boarding_train,p.boarding_station,p.destination_station);
	printf("Train id:%d",p.train_no);
}
Passenger* search(Passenger passenger_record,int *pos,TreeNode *node)
{
    if(node!=NULL)
    {
        if(passenger_record.key<node->data[1].key)
            *pos=0;
        else
        {
            for(*pos=node->size;(passenger_record.key < node->data[*pos].key && *pos>1);(*pos)--);
            if(passenger_record.key==node->data[*pos].key)
            {
                printf("Train found\n");
                return &node->data[*pos];
            }
        }
        search(passenger_record,pos,node->ptr[*pos]);
    }
    return NULL;
}
void copy(TreeNode *node,int pos)
{
    TreeNode *temp;
    temp=node->ptr[0];
    while(temp->ptr[0]!=NULL)
        temp=temp->ptr[0];
    node->data[pos]=temp->data[1];
}
void remVal(TreeNode *node,int pos)
{
    int i;
    for(i=pos+1;i<=node->size;i++)
    {
        node->data[i-1]=node->data[i];
        node->ptr[i-1]=node->ptr[i];
    }
    node->size--;
}
void rightShift(TreeNode* node,int pos)
{
    TreeNode*x=node->ptr[pos];
    int i=x->size;
    while(i>0)
    {
        x->data[i+1]=x->data[i];
        x->ptr[i+1]=x->ptr[i];
        i++;
    }
    x->data[1]=node->data[pos];
    x->ptr[1]=node=x->ptr[0];
    x->size++;
    x = node->ptr[pos-1];
    node->data[pos]=x->data[x->size];
    node->ptr[pos]=x->ptr[x->size];
    x->size--;   
}
void leftShift(TreeNode* node,int pos)
{
    int i=1;
    TreeNode *x=node->ptr[pos-1];
    x->size++;
    x->data[x->size]=node->data[pos];
    x->ptr[x->size]=node->ptr[pos]->ptr[0];
    x=node->ptr[pos];
    node->data[pos]=x->data[1];
    x->ptr[0]=x->ptr[1];
    x->size--;
    while(i<=x->size)
    {
        x->data[i]=x->data[i+1];
        x->ptr[i]=x->ptr[i+1];
        i++;
    }
}
void mergeNodes(TreeNode*node ,int pos)
{
    int i=1;
    TreeNode *node1=node->ptr[pos],*node2=node->ptr[pos-1];
    node2->size++;
    node2->data[node2->size]=node->data[pos];
    node2->ptr[node2->size]=node->ptr[0];
    while(i<=node1->size)
    {
        node2->size++;
        node2->data[node2->size]=node1->data[i];
        node2->ptr[node2->size]=node->ptr[i];
        i++;
    }
    i=pos;
    while(i<node->size)
    {
        node->data[i]=node->data[i+1];
        node->ptr[i]=node->ptr[i+1];
        i++;
    }
    node->size--;
    free(node1);
}
void adjustNode(TreeNode *node,int pos)
{
    if(!pos)
    {
        if(node->ptr[1]->size>MIN)
        {
            leftShift(node,1);
        }
        else
        {
            mergeNodes(node,1);
        }
    }
    else
    {
        if(node->size!=pos)
        {
            if(node->ptr[pos-1]->size >MIN)
            {
                rightShift(node,pos);
            }
            else
            {
                if(node->ptr[pos+1]->size>MIN)
                {
                    leftShift(node,pos+1);
                }
                else
                {
                    mergeNodes(node,pos);
                }
            }
        }
        else
        {
            if(node->ptr[pos-1]->size>MIN)
                rightShift(node,pos);
            else
                leftShift(node,pos);
        }
    }
}
bool delVal(Passenger passenger_record,TreeNode* node)
{
    int pos;
    bool flag=false;
    if(node)
    {
        if(passenger_record.key<node->data[1].key)
        {
            pos=0;
            flag=false;
        }
        else
        {
            pos=node->size;
            while(passenger_record.key<node->data[pos].key&&pos>1)
                pos--;
            if(passenger_record.key == node->data[pos].key)
                flag=true;
            else
                flag=false;
        }
        if(flag)
        {
            if(node->ptr[pos-1])
            {
                copy(node,pos);
                flag=delVal(node->data[pos],node->ptr[pos]);
                if(flag==false)
                    printf("Deletion failed!\n");
            }
            else
                remVal(node,pos);
        }
        else
            flag=delVal(passenger_record,node->ptr[pos]);
        if(node->ptr[pos])
            if(node->ptr[pos]->size <MIN)
                adjustNode(node,pos);
    }
    return flag;
}
void delete(Passenger passenger_record,TreeNode *node)
{
    TreeNode*temp;
    if(delVal(passenger_record,node))
    {
        printf("Record not found!\n");
        return;
    }
    else
    {
        if(node->size==0)
        {
            temp=node;
            node=node->ptr[0];
            free(temp);
            printf(" Reservation cancelled successfully");
        }
        printf("Reservation Cancellation failed.");
    }
    root=node;
    
}

//Helper function for MergeSort()
//Function to merge two sorted lists in a sorted fashion

FR_Node *Merge(TreeNode Node *lptr, TreeNode *nptr, boolean (*comp)(TreeNode *, TreeNode *)) //Assuming lptr and nptr each have atleast one node
{
	TreeNode *result, *ptr1, *ptr2, *tail;

	ptr1 = lptr;
	ptr2 = nptr;

	if (comp(ptr1, ptr2))
	{
		result = ptr1;
		ptr1 = ptr1->next;
	}
	else
	{
		result = ptr2;
		ptr2 = ptr2->next;
	}
	tail = result;

	while (ptr1 != NULL && ptr2 != NULL)
	{
		if (comp(ptr1, ptr2))
		{
			tail->next = ptr1;
			tail = tail->next;
			ptr1 = ptr1->next;
		}
		else
		{
			tail->next = ptr2;
			tail = tail->next;
			ptr2 = ptr2->next;
		}
	}

	if (ptr1 != NULL)
	{
		tail->next = ptr1;
	}
	else
	{
		tail->next = ptr2;
	}

	return result;
}

//Helper function for MergeSort()
//Function to split a list into two lists of equal size

TreeNode *Divide(TreeNode *lptr)
{
	TreeNode *nptr, *ahead, *prev;
	//Taking two ptrs, one moves one step ahead, another moves two steps ahead.
	prev = lptr;
	ahead = lptr->next->next;
	while (ahead != NULL)
	{
		ahead = ahead->next;
		prev = prev->next;

		if (ahead != NULL)
		{
			ahead = ahead->next;
		}
	}
	nptr = prev->next;
	prev->next = NULL;

	return nptr;
}

//Function to sort a list based on a comparator function
//returns the head of the sorted list
TreeNode *MergeSort(TreeNode *list_ptr, )
{
	TreeNode *nptr, *lptr, *comp;
	lptr = list_ptr;

	if ((lptr != NULL) && (lptr->next != NULL))
	{
		nptr = Divide(lptr);
		lptr = MergeSort(lptr, comp);
		nptr = MergeSort(nptr, comp);
		lptr = Merge(lptr, nptr, comp);
	}

	return lptr;
}


void SortTrains(TreeNode *node)
{
	Treeptr->listptr = MergeSort(Treeptr->listptr);
	Treeptr->isSortedOnKey = FALSE;
}



TreeNode* SortByTravelDate(TreeNode *node, int passengerID){
    TreeNode *TravelDate=NULL;
    int i;
    if(node){
        for(i=0;i<node->size;i++)
        {
           TravelDate=SortByTravelDate(node->ptr[i]);
           insertbydate(TravelDate,node->data[i+1]);
        }
        TravelDate=SortByTravelDate(node->ptr[i]);
    }
    return TravelDate;
}

void threelistUpdate(TreeNode *rootnode,TreeNode *sTree,TreeNode *AC3,TreeNode *AC2,TreeNode *AC1)
{
    int i;
    if(rootnode)
    {
        for(i=0;i<rootnode->size;i++)
        {
            threelistUpdate(rootnode->ptr[i],sTree,AC3,AC2,AC1);
            switch(rootnode->data[i+1].train_class)
            {
                case 0: {
                    bool f = insert(sTree, rootnode->data[i + 1].name, rootnode->data[i + 1].passengerID,
                                    rootnode->data[i + 1].boarding_train, rootnode->data[i + 1].boarding_station,
                                    rootnode->data[i + 1].train_class,
                                    rootnode->data[i + 1].destination_station,rootnode->data[i + 1].train_no);
                    break;
                }
                case 1: {
                    bool f = insert(AC3, rootnode->data[i + 1].name, rootnode->data[i + 1].passengerID,
                                    rootnode->data[i + 1].boarding_train, rootnode->data[i + 1].boarding_station,
                                    rootnode->data[i + 1].train_class,
                                    rootnode->data[i + 1].destination_station,rootnode->data[i + 1].train_no);
                    break;
                }
                case 2: {
                    bool f = insert(AC2, rootnode->data[i + 1].name, rootnode->data[i + 1].passengerID,
                                    rootnode->data[i + 1].boarding_train, rootnode->data[i + 1].boarding_station,
                                    rootnode->data[i + 1].train_class,
                                    rootnode->data[i + 1].destination_station,rootnode->data[i + 1].train_no);
                    break;
                }
                case 3: {
                    bool f = insert(AC1, rootnode->data[i + 1].name, rootnode->data[i + 1].passengerID,
                                    rootnode->data[i + 1].boarding_train, rootnode->data[i + 1].boarding_station,
                                    rootnode->data[i + 1].train_class,
                                    rootnode->data[i + 1].destination_station,rootnode->data[i + 1].train_no);
                    break;
                }
            }
        }
    }
}
void RangeSearch(TreeNode *node,int start,int end)
{
    int i;
    if(node)
    {
        for(i=0;i<node->size;i++)
        {
            RangeSearch(node->ptr[i],start,end);
            if(node->data[i+1].train_no>=start&&node->data[i+1].train_no<=end)
            {
                printTrain(node->data[i+1]);
            }
        }
        RangeSearch(node->ptr[i],start,end);
    }
}
int main()
{
    int i,insert_flag;
    TreeNode root=(TreeNode)malloc(sizeof(TreeNode));
    TreeNode sTree=(TreeNode)malloc(sizeof(TreeNode));
    TreeNode AC3=(TreeNode)malloc(sizeof(TreeNode));
    TreeNode AC2=(TreeNode)malloc(sizeof(TreeNode));
    TreeNode AC1=(TreeNode)malloc(sizeof(TreeNode));

    root=NULL;
    sTree=NULL;
    AC3=NULL;
    AC2=NULL;
    AC1=NULL;

    int response,flag=0;
    while(flag==0){
        printf("\nEnter the process number to perform\n");
        printf("1. Insert/Update a record\n");
        printf("2. Delete a record\n");
        printf("3. To getListDestination\n");
        printf("4. To Sort By Travel Date\n");
        printf("6. To Range search\n");
        printf("7. Print List\n");

        printf("0. Exit\n");
        scanf("%d",&response);
        
        switch(response)
        {
            case 1:
            {
                int i,n;
                printf("Enter Number of Records: ");
                scanf("%d",&n);
                for(i=0;i<n;i++)
                {
                    bool insert_flag;
                    int passengerID,train_no;
                    char name[NAME_SIZE];
                    char boarding_train[20],boarding_station[20];
                    char destination_station[20];
                    int train_class;
                    //status train_status;
                    printf("Enter the Record:\nName: ");
                    scanf("%s",name);
                    printf("Enter Class:\n\t0)sleeper\n\t1)3AC\n\t2)2AC\n\t3)1AC");
                    scanf("%d",&train_class);
                    printf("Enter ID: ");
                    scanf("%d",&passengerID);
                    printf("Enter boarding train: ");
                    scanf("%s",boarding_train);
                    printf("Enter boarding station: ");
                    scanf("%s",boarding_station);
                    printf("Enter destination station: ");
                    scanf("%s",destination_station);
                    printf("Enter train id:");
                    scanf("%d",&train_no);
                    /*printf("Enter Status:\n\t0)Cancelled\n\t1)Promoted\n");
                    scanf("%d",&train_status);*/
                    insert_flag=insert(root,name,passengerID,boarding_train,boarding_station,train_class,destination_station,train_no);
                }
                threelistUpdate(root,sTree,AC3,AC2,AC1);
                if (insert_flag==true)
                    {
                        printf("Inserted!\n");
                    }
                    else
                    {
                        printf("Error, couldn't insert record\n");
                    }
                
                break;
            }
            case 2:
            {
                int passengerID;
                printf("Enter id: ");
                scanf("%d",&passengerID);
                Passenger passenger_record;
                passenger_record.passengerID=passengerID;
                delete(passenger_record,root);
                threelistUpdate(root,sTree,AC3,AC2,AC1);
                break;
            }
            case 3:
            	{
            		Passenger *head= NULL;
            		getListDestination(head);
            		break;
            		
				}
			case 4:
				{
					printf("Enter the passenger id: ");
                    scanf("%d",&passengerID);
                    TreeNode *node = NULL;
                    printf("Sorted by travel date : \n");
                    SortByTravelDate(node,passengerID);
                    break;
                    
                    

				}
			case 5:
				{
				SortTrains(root);
				printf("List of sorted trains : \n");
				break;
				}
				
            case 6:
            {
                int start,end;
                printf("Enter the from train number and to train number:");
                scanf("%d %d",&start,&end);
                RangeSearch(root,start,end);
                break;
            }
            case 7:
            {
                printf("Enter the Number corresponding to list you want to print details:\n");
                printf("1. Complete List\n");
                printf("2. List with sleeper \n");
                printf("3. List with 3AC \n");
                printf("4. List with 2AC \n");
                printf("4. List with 1AC \n");
                printf("5. Entire combined\n");
                int response2;
                scanf("%d",&response2);
                switch(response2)
                {
                    case 1:
                        print_details(root);
                        break;
                    case 2:
                        print_details(sTree);
                        break;
                    case 3:
                        print_details(AC3);
                        break;
                    case 4:
                        print_details(AC2);
                        break;
                    case 5:
                        print_details(AC1);
                        break;
                    case 6:
                        print_details(root);
                        print_details(sTree);
                        print_details(AC3);
                        print_details(AC2);
                        print_details(AC1);
                        break;
                    default:
                        break;
                }   
            } 
            case 0:
            default:
                flag=1;
                break;
        }
    }
    
}

